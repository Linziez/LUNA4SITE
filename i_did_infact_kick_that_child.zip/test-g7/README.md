if this file is floating somewhere on the internet this bypass was made by frogie's arcade 
https://discord.gg/fErn6KteQn